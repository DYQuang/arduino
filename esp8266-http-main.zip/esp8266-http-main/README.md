some HTTP POST and GET examples with ESP8266.
